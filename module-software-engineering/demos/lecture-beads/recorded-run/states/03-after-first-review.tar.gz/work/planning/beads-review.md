# Review of the filed Beads records (epic ttt-cik and children .1–.4)

Method: read every record in full with `bd show`, compared against `planning/beads-plan.md`,
`specs/001-five-in-a-row/tasks.md` (T018–T024, Notes), `contracts/cli.md`, the spec's US1 text, and
the existing `cli/app.py`, `tests/cli/*`, `tests/conftest.py`. Also ran `uv run --frozen --offline pytest -q`
(44 passed; the command in the records works). Refinements were added with `bd update`
(notes and acceptance); the original descriptions were not rewritten, so the notes headed
"REVIEW 1 REFINEMENTS" are binding where they differ.

## Findings and corrections

| # | Record | Finding | Correction |
|---|--------|---------|------------|
| 1 | .2 | Description said only choice `1` still raises `NotImplementedError`; at refactor time choice `2` does too. | Note + acceptance corrected. |
| 2 | .2 | "Parse_menu per C-1/C-2" invited `int()`, which accepts `01`, `+1`; current menu accepts only exact `1/2/3` after strip, so a naive refactor would change behavior (breaking the II(b) claim). | Required identical behavior; added tests `01`, `+1` → None and the `choices` boundary. |
| 3 | .2 | Ambiguous whether failing tests are committed (a red commit would break "full suite verified"). | Tests and code land together in the II(c) commit; failing-run evidence goes in notes; II(b) is a later commit after a green run on the II(c) commit. Same rule added to .1, .3. |
| 4 | .2 | "Signed integer" in C-7/T022 is silent on `+4 7` and non-ASCII digits. | Recorded as D2; narrowest reading (optional `-`, ASCII digits), report choice; no test pins it. |
| 5 | .1 | T021 builds prompt, rejection and result text, but T018 tests only `render_board`; those texts have no test in .1. | Stated explicitly that their evidence is .3; no extra tests invented. |
| 6 | .1/.3 | Function names for text helpers are unspecified; .3 would guess. | Suggested names given (non-binding), chosen names to be recorded at close; wording constraints .3 tests rely on made explicit (`range`, `occupied`, exact result lines). |
| 7 | .3 | T020 says the transcript "ends with a result line", T023 returns to the start menu afterward. Direct contradiction in `tasks.md`. | Recorded as D1; tests assert order and absence of a later move prompt, not `endswith`. |
| 8 | .3 | C-5 (redraw after each move) and C-12 (final board drawn) may double-draw; unspecified. | Recorded as D3; tests use `>= moves+1` and ordering only. |
| 9 | .3 | C-8 does not say if the board is redrawn after a rejection; "board unchanged" had no testable form. | Tests assert one reason line, no new mark, same mark re-prompted; scripts may end with EOF. |
| 10 | .3 | `session()` returns only a transcript but the EOF test needs the return code; `ScriptedOpponent` could import the not-yet-existing opponent package. | Directions added (call `run()` directly or extend helper; use engine `Square` only). Out-of-range must reach `GameState.play`. |
| 11 | .4 | "Unchanged" diffs had no baseline. | Baseline commit `f803ba7` added to epic and .4; diff paths listed. Added report checks (no FAIL, Unknown IDs none), commit-type check, closing order. |
| 12 | epic | No baseline/closure rule; commit-trailer conflict (session requires a Co-Authored-By trailer vs "ends with Change type"). | Epic note: Change-type line comes immediately before the trailer; epic closes after .4. |

Checked and left as is: dependencies (.3 ← .1, .2; .4 ← .3; .1 and .2 independent; transitive
chain needs no extra edges); no duplicated work between issues; every original ID T018–T024
appears in a title and label; II(c)/II(b) split is inside .2; no US3, `m`, or computer-play
scope; design refs are project-relative paths.

## Open items for a developer ruling (not resolved here; non-blocking)
- **D1** `tasks.md` T020 ("transcript ends with a result line") vs T023 (returns to the start menu).
- **D2** C-7/T022 "signed integer": `+4 7` and non-ASCII digits.
- **D3** Whether the final board after a winning move is drawn once or twice (C-5 vs C-12), and
  whether a rejection redraws the board.
- Known staged gap (already ruled): C-6/FR-018/C-9 `m` hint and handling deferred to US3; FR-018 not claimed.

## Limitations
No separate decision issues were created, to avoid extra scope; the items live in notes and
here. The descriptions of .1–.4 still contain the superseded statements (finding 1) next to
the corrective notes. The records were reviewed by the same agent that wrote them.

## Result
Records refined and consistent with the plan. Graph unchanged: `bd ready` lists the epic,
.1 and .2; .3 and .4 are blocked. Ready to start .1 or .2.

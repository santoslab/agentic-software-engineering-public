"""Reading what the player typed (contracts/cli.md C-7).

Parsing is syntactic only: whether a square is on the board or free is the engine's call.
"""

import re

from five_in_a_row.engine import Square

_MOVE = re.compile(r" *(-?[0-9]+)(?: +| *, *)(-?[0-9]+) *")


def parse_move(text: str) -> Square | None:
    """Row and column from `4 7`, `4,7` or ` 4 , 7 `; None if the entry is unreadable."""
    match = _MOVE.fullmatch(text)
    if match is None:
        return None
    return Square(int(match.group(1)), int(match.group(2)))

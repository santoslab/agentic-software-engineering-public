# Reproduce the Beads / Sonnet tic-tac-toe demonstration

This bundle contains the unfinished game starter and the exact staged prompts
for a recorded Beads lecture demonstration. It does not contain a completed
implementation, an issue database, credentials, or prior conversation logs.
Sonnet does the planning, Beads creation/review, implementation, and handoff.

Source: [public course project at checkpoint 4d6a2cd](https://github.com/santoslab/agentic-software-engineering-public/tree/4d6a2cd/module-software-engineering/demos/lecture-speckit-intro-tic-tac-toe).
The full commit and subtree are in source.json. Source, tests, specifications,
and contracts are exported unchanged; added instructions select T018–T024,
retain tasks.md as planning input, and make Beads authoritative for live status.
The bundle adds pinned Beads 1.3.2 package files and the course's licenses.

## Requirements and setup

Use an authenticated Claude Code CLI with access to Sonnet, Git, Node.js/npm,
uv, and Python 3.12 or newer. Installing the locked dependencies needs network
access. Sonnet calls consume your account's usage. The recorder uses the
sonnet alias unless --model is supplied and saves the model actually returned.
It caps each invocation at an estimated USD 8 through Claude's CLI budget flag;
that client-side estimate is not a statement of the subscription's actual bill.

From a freshly extracted bundle:

```sh
sh setup.sh
```

This copies starter/ to work/, initializes an independent local Git repository,
installs the pinned dependencies, and runs bd init. There is no remote.
For manual bd commands, add work/node_modules/.bin to PATH first.

## Planning, filing beads, and iterative review

The create-beads prompt includes execution clarifications prompted by the first
planning pass: unit tests and scheduling stay within the agreed behavior, later
US3 behavior stays deferred, and one parsing bead spans the intended interruption.
Those clarifications are part of the recorded prompt, not unrecorded code edits.

The prompts follow [Steve Yegge's workflow](https://steve-yegge.medium.com/beads-best-practices-2db636b9760c):
refine the plan outside Beads; ask the agent to file detailed epics/issues;
then ask it to review and refine the actual records. Review happens within the
existing approved scope; specification gaps need a developer ruling.

```sh
python3 run-session.py --project work --prompt prompts/01-plan.txt --output recordings/01-plan
planning_session=$(python3 -c 'import json; print(json.load(open("recordings/01-plan.metadata.json"))["session_id"])')
python3 run-session.py --project work --prompt prompts/02-create-beads.txt --output recordings/02-create-beads --resume "$planning_session"
python3 run-session.py --project work --prompt prompts/03-review-beads.txt --output recordings/03-review-beads --resume "$planning_session"
python3 run-session.py --project work --prompt prompts/04-review-again.txt --output recordings/04-review-again --resume "$planning_session"
```

Inspect each result before continuing. The first prompt asks for a review of
the plan, and the later prompts request two actual bead-review passes. This
is a chosen demonstration sequence, not a claim that a fixed pass count is best.
If the agent reports an unresolved specification conflict, obtain a ruling
and record it before affected implementation. Do not silently fix the intent.

## Interrupted implementation and fresh recovery

```sh
python3 run-session.py --project work --prompt prompts/05-interrupted-implementation.txt --output recordings/05-interrupted-implementation
python3 run-session.py --project work --prompt prompts/06-fresh-recovery.txt --output recordings/06-fresh-recovery
```

The first implementation prompt deliberately stops after move parsing, leaving
menu parsing and the required start-menu caller refactor unfinished. The agent
must save a real partial commit and record the handoff on the active bead.
The second invocation omits --resume/--continue, has a different session ID,
and receives no previous transcript. It must report its recovered task/context
before editing, then complete only the active issue.

The recorder disables automatic Claude memory, loads only project settings,
disables slash commands, and exposes only the local read/edit/shell tools.
Project instructions and generated bd hooks are intentional persistent context.
The full CLI arguments, prompts, model/session IDs, stderr, raw JSONL events,
and readable Markdown transcripts are saved outside work/. Do not give those
recordings to the recovery agent. The JSONL is the original CLI stream; the
Markdown view is derived from its messages and tool events, not a recreation
from the final answer. Inspect the original stream and actual files when
assessing success. A fresh conversation still has the harness's system prompt,
project guidance, Beads, and project files; it is not an empty environment.

## Optional: finish the milestone one task per fresh session

If only the parser is complete, use prompt 07 for the next ready implementation
task, then use it again in another fresh session for the remaining implementation:

```sh
python3 run-session.py --project work --prompt prompts/07-next-ready-task.txt --output recordings/07-next-ready-task
python3 run-session.py --project work --prompt prompts/07-next-ready-task.txt --output recordings/08-next-ready-task
python3 run-session.py --project work --prompt prompts/08-final-verification.txt --output recordings/09-final-verification
```

Inspect ready work before using this optional sequence: the agent chooses the
actual decomposition, so the number of issues may differ. Do not run the final
verification before its prerequisites are met. The target is only US1's
T018–T024 milestone, not the computer opponent or later US3 menu features.

Judge recovery using the recorded task, references, completed/remaining work,
and first resumed action. Compare those claims with the actual diff and tests.
A single demonstration is not a comparative evaluation of Beads effectiveness.
Agent outputs, issue IDs, test counts, and decomposition can differ on rerun.

CLI reference: [programmatic runs](https://code.claude.com/docs/en/headless),
[model selection](https://code.claude.com/docs/en/model-config).
Instructional content: CC BY 4.0; scripts/configuration: MIT. See starter/LICENSE-CC-BY-4.0 and starter/LICENSE-MIT.

# Restore a recorded checkpoint

Every session-state archive contains work/ (including its local .git history
and .beads state), cumulative transcripts/, evidence/, prompts/, and the
transcript recorder. These are recorded states, separate from the pristine
starter archive. REPRODUCE.md describes starting from that input bundle;
use the commands below for an already initialized checkpoint.

Extract an archive into a new directory, then install its locked dependencies:

```sh
cd work
npm ci
export PATH="$PWD/node_modules/.bin:$PATH"
uv sync --frozen
bd list --all
bd ready
git log --oneline
```

The project is already initialized; use its saved Git and Beads state.
To replay the interrupted handoff, select 05-after-interruption.tar.gz, then
from the archive's top-level directory run:

```sh
python3 run-session.py --project work --prompt prompts/06-fresh-recovery.txt --output new-recordings/recovery --model claude-sonnet-5-5
```

This starts a new conversation and disables automatic memory. Start the agent
in work/ and keep transcripts/ and new-recordings/ outside that working tree.
The snapshot includes recorded transcripts for inspection; do not supply them
to the recovery agent. Exact original CLI arguments and session/model IDs are
in the metadata beside each transcript.

The original orchestration environment had a revoked OAuth token override.
Successful recorded calls used `env -u CLAUDE_CODE_OAUTH_TOKEN` before the
recorder to use the user's already valid stored subscription login. That
child-process change did not modify the user's login or shell configuration.
Students using an intentional valid environment token can keep their own setup.

The archives exclude node_modules, virtual environments and Python/pytest
caches. The raw issue export is provided for inspection/interchange alongside
the saved database; the export alone does not preserve all database history.
Archive restoration is checked on the recorded macOS environment, not every
operating system. Restored CLI metadata and notes may retain the original
/tmp paths; use the current work/ location for commands. The source, tasks,
contracts, and requirement tags remain project-relative.

The checkpoint's agent claims should be assessed against its files, commits,
test output, and transcript. In the original recovery session, the agent found
and completed the remaining menu work but skipped the requested explicit
understanding/next-action report before editing. That miss is preserved in
its observation record. The after-recovery and after-milestone states are
outputs to inspect, not pristine inputs for another identical first run.

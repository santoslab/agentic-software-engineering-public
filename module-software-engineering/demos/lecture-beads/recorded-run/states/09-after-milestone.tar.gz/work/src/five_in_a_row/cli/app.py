"""The session loop: start menu, games, end of input (contracts/cli.md)."""

from typing import TextIO

from five_in_a_row.cli.parse import parse_menu, parse_move
from five_in_a_row.cli.render import move_prompt, rejection_message, render_board, result_line
from five_in_a_row.engine import GameState, IllegalMove, Result

TITLE = "Five-in-a-Row — 9×9, five or more in a line wins."
START_MENU = ("Play the computer", "Play a friend", "Quit")
GOODBYE = "Goodbye."


class _EndOfInput(Exception):
    """Input ended (EOF); the session ends as for an interrupt (C-17)."""


class _App:
    def __init__(self, stdin: TextIO, stdout: TextIO, opponent_factory) -> None:
        self._in = stdin
        self._out = stdout
        self._opponent_factory = opponent_factory

    def say(self, text: str = "") -> None:
        self._out.write(text + "\n")

    def ask(self, prompt: str) -> str:
        self._out.write(prompt + " ")
        self._out.flush()
        line = self._in.readline()
        if line == "":
            raise _EndOfInput
        return line.rstrip("\n")

    def run(self) -> int:
        try:
            self.start_menu()
        except (_EndOfInput, KeyboardInterrupt):
            self.say()
            self.say(GOODBYE)
        return 0

    def start_menu(self) -> None:
        while True:
            self.say()
            self.say(TITLE)
            self.say()
            for number, label in enumerate(START_MENU, start=1):
                self.say(f"  {number}  {label}")
            self.say()
            entry = self.ask("Choose 1, 2 or 3:").strip()
            choice = parse_menu(entry, len(START_MENU))
            if choice == 3:
                return
            if choice == 2:
                self.two_player_game()
                continue
            if choice == 1:
                raise NotImplementedError("computer play arrives with User Story 2")
            self.say(f"'{entry}' is not a choice.")

    def two_player_game(self) -> None:
        """Play one game to its result, then return (interim until T034's game-over menu)."""
        state = GameState.new()
        self.say()
        self.say(render_board(state.board))
        while state.result is Result.IN_PROGRESS:
            self.say()
            entry = self.ask(move_prompt(state.turn))
            square = parse_move(entry)
            if square is None:
                self.say(rejection_message(None))
                continue
            try:
                state = state.play(square)
            except IllegalMove as rejected:
                self.say(rejection_message(rejected.reason))
                continue
            self.say()
            self.say(render_board(state.board))
        self.say()
        self.say(result_line(state.result))


def run(stdin: TextIO, stdout: TextIO, opponent_factory=None) -> int:
    """Run one session on the given streams; return the exit status (contracts/cli.md §1)."""
    return _App(stdin, stdout, opponent_factory).run()

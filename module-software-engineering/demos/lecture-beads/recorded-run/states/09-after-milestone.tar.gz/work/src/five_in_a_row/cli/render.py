"""Text the player sees: board, prompt, rejections and results (contracts/cli.md C-5 – C-8, C-12, C-13).

Pure functions that return strings; the caller does the terminal I/O.
"""

from five_in_a_row.engine import SIZE, Board, IllegalMoveReason, Mark, Result, Square


def render_board(board: Board) -> str:
    """The board with column numbers across the top and row numbers down the left."""
    lines = ["    " + " ".join(str(col) for col in range(1, SIZE + 1))]
    for row in range(1, SIZE + 1):
        cells = (board.at(Square(row, col)) for col in range(1, SIZE + 1))
        lines.append(f"{row:>2}  " + " ".join(m.value if m else "." for m in cells))
    return "\n".join(lines)


def move_prompt(mark: Mark) -> str:
    """Names the mark to move and how to enter a square (the leave-game hint is US3's)."""
    return f"{mark.value} to move — type row and column (e.g. 4 7):"


def rejection_message(reason: IllegalMoveReason | None) -> str:
    """One line for a rejected entry; None means the entry was unreadable."""
    if reason is IllegalMoveReason.OUT_OF_RANGE:
        return f"Out of range: row and column must each be 1 to {SIZE}."
    if reason is IllegalMoveReason.OCCUPIED:
        return "That square is occupied; choose an empty one."
    return "Not understood: type a row and a column, like 4 7."


def result_line(result: Result) -> str:
    """The two-player result line for a finished game."""
    if result is Result.X_WON:
        return "X wins!"
    if result is Result.O_WON:
        return "O wins!"
    if result is Result.DRAW:
        return "It's a draw."
    raise ValueError(f"game not finished: {result}")

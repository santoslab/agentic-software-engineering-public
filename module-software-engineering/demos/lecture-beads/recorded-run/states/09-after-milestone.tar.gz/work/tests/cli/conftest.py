"""Helpers for the CLI transcript tests (tasks.md T020; contracts/cli.md §1)."""

import io

from five_in_a_row.cli import run
from five_in_a_row.engine import Square


class ScriptedOpponent:
    """Plays the given (row, col) pairs in order; one instance serves a whole series."""

    def __init__(self, moves):
        self._moves = iter(moves)

    def choose_move(self, state):
        row, col = next(self._moves)
        return Square(row, col)


def session(lines, opponent_moves=()):
    """Run the CLI on `lines` (one entry per input line); return the output transcript."""
    out = io.StringIO()
    stdin = io.StringIO("".join(f"{line}\n" for line in lines))
    run(stdin, out, opponent_factory=lambda: ScriptedOpponent(opponent_moves))
    return out.getvalue()

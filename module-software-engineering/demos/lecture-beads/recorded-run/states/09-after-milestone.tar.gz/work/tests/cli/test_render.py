"""Evidence for contracts/cli.md C-5: the board drawing shows every mark and its coordinates.

Facts are checked, not spacing (contracts/cli.md, "Normative vs. illustrative").
"""

import pytest

from five_in_a_row.cli.render import render_board
from five_in_a_row.engine import SIZE, GameState, Square

req = pytest.mark.req


def _board_with_marks():
    state = GameState.new()
    for square in (Square(1, 1), Square(5, 5), Square(9, 9)):  # X, O, X
        state = state.play(square)
    return state.board


@req("FR-006", "FR-004")
def test_board_has_numbered_columns_numbered_rows_and_every_mark():
    lines = [line.split() for line in render_board(_board_with_marks()).splitlines() if line.strip()]

    assert lines[0] == [str(n) for n in range(1, SIZE + 1)]
    rows = lines[1:]
    assert [row[0] for row in rows] == [str(n) for n in range(1, SIZE + 1)]

    cells = {(r, c): rows[r - 1][c] for r in range(1, SIZE + 1) for c in range(1, SIZE + 1)}
    assert all(len(row) == SIZE + 1 for row in rows)
    assert cells[(1, 1)] == "X"
    assert cells[(5, 5)] == "O"
    assert cells[(9, 9)] == "X"
    assert sum(1 for v in cells.values() if v == ".") == SIZE * SIZE - 3

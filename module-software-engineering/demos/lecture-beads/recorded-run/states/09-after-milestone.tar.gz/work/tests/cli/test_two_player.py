"""Evidence for contracts/cli.md §3 and §4 in two-player games: a full game from the menu.

Scripts end at the result line or at end of input: what follows a finished game changes
in US3 (tasks.md T020), so nothing here asserts it.
"""

import io

import pytest

from five_in_a_row.cli import run
from tests.cli.conftest import session
from tests.positions import DRAW_MOVES, O_WINS_MOVES, X_WINS_MOVES

req = pytest.mark.req

HEADER = "1 2 3 4 5 6 7 8 9"


def typed(moves):
    return ["2"] + [f"{row} {col}" for row, col in moves]


def events(text):
    """The transcript as ("board", marks_on_it), ("prompt", mark) and ("line", text) events."""
    lines = text.splitlines()
    found = []
    i = 0
    while i < len(lines):
        line = lines[i]
        if line.strip() == HEADER:
            rows = lines[i + 1 : i + 10]
            found.append(("board", sum(r.count("X") + r.count("O") for r in rows)))
            i += 10
            continue
        if "to move" in line:
            # input is not echoed, so whatever is printed next follows the prompt on its line
            prompt, _, rest = line.partition("):")
            found.append(("prompt", prompt.strip()[0]))
            if rest.strip():
                found.append(("line", rest.strip()))
        elif line.strip():
            found.append(("line", line.strip()))
        i += 1
    return found


def kinds(found, kind):
    return [value for k, value in found if k == kind]


def check_full_game(moves, result_text):
    found = events(session(typed(moves)))
    # the board is drawn before every prompt, showing exactly the moves played so far
    boards_seen = None
    prompts = 0
    for kind, value in found:
        if kind == "board":
            boards_seen = value
        elif kind == "prompt":
            assert boards_seen == prompts
            assert value == "XO"[prompts % 2]
            prompts += 1
    assert prompts == len(moves)
    result_at = next(i for i, (k, v) in enumerate(found) if k == "line" and result_text in v)
    assert found[result_at - 1] == ("board", len(moves))  # final board, then the result
    assert not [e for e in found[result_at:] if e[0] == "prompt"]  # no further move requested
    assert len(kinds(found, "board")) >= len(moves) + 1
    return found


@req("FR-002", "FR-003", "FR-006", "FR-007", "FR-009", "FR-011", "US1-1", "US1-2", "US1-3")
def test_x_wins_a_full_game():
    check_full_game(X_WINS_MOVES, "X wins")


@req("FR-002", "FR-003", "FR-006", "FR-007", "FR-009", "FR-011", "US1-1", "US1-2", "US1-3")
def test_game_starts_with_an_empty_board_and_x_to_move():
    found = events(session(["2"]))
    start = found.index(("board", 0))
    assert found[start + 1] == ("prompt", "X")


@req("FR-006", "US1-2")
def test_a_move_appears_on_the_board_and_o_is_asked_next():
    found = events(session(typed(X_WINS_MOVES[:1])))
    assert ("board", 1) in found
    assert kinds(found, "prompt")[:2] == ["X", "O"]


@req("FR-009", "SC-003")
def test_o_wins_a_full_game():
    check_full_game(O_WINS_MOVES, "O wins")


@req("FR-010", "US1-7", "SC-003")
def test_a_full_board_without_a_line_is_a_draw():
    found = check_full_game(DRAW_MOVES, "draw")
    assert not [v for k, v in found if k == "line" and "wins!" in v]


@req("FR-005", "SC-006", "EDGE-occupied-square")
def test_occupied_square_is_rejected_and_the_same_mark_asked_again():
    found = events(session(["2", "1 1", "1 1"]))
    assert sum("occupied" in v for k, v in found if k == "line") == 1
    assert kinds(found, "prompt")[:3] == ["X", "O", "O"]
    assert [v for k, v in found if k == "board"][-1] == 1


@req("FR-005", "SC-006", "EDGE-out-of-range-square")
def test_out_of_range_square_is_rejected_and_the_same_mark_asked_again():
    found = events(session(["2", "0 3"]))
    assert sum("range" in v for k, v in found if k == "line") == 1
    assert kinds(found, "prompt")[:2] == ["X", "X"]
    assert [v for k, v in found if k == "board"][-1] == 0


@req("FR-005", "SC-006", "EDGE-unreadable-input")
def test_unreadable_input_is_rejected_and_the_same_mark_asked_again():
    found = events(session(["2", "abc"]))
    assert sum("not understood" in v.lower() for k, v in found if k == "line") == 1
    assert kinds(found, "prompt")[:2] == ["X", "X"]
    assert [v for k, v in found if k == "board"][-1] == 0


@req("FR-011")
def test_the_opponent_factory_is_not_called_in_two_player_games():
    def factory():
        raise AssertionError("opponent_factory called in a two-player game")

    stdin = io.StringIO("".join(f"{line}\n" for line in typed(X_WINS_MOVES)))
    assert run(stdin, io.StringIO(), opponent_factory=factory) == 0


@req("FR-020", "US3-6", "EDGE-end-of-input-or-interrupt")
def test_end_of_input_mid_game_prints_goodbye_and_returns_zero():
    out = io.StringIO()
    stdin = io.StringIO("".join(f"{line}\n" for line in typed(X_WINS_MOVES[:2])))
    code = run(stdin, out, opponent_factory=lambda: None)
    text = out.getvalue()
    assert code == 0
    assert len([ln for ln in text.splitlines() if "goodbye" in ln.lower()]) == 1
    assert "Traceback" not in text

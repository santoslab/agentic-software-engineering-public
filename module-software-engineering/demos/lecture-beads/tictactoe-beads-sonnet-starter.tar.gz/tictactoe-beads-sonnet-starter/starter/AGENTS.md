# Beads lecture: tic-tac-toe working copy

This is an independent copy of the public course game's foundational checkpoint.
Read `.specify/memory/constitution.md` and `specs/001-five-in-a-row/` before work.

## Agreed scope and policy

- Implement only the two-player milestone, original tasks T018–T024. The 9×9
  game needs five or more in a row. Computer play and the later US3 menus
  remain outside this milestone. Preserve the existing start-menu and EOF tests.
- The Spec Kit artifacts define intended behavior. Keep `tasks.md` unchanged
  as the original planning input; Beads is authoritative for live status,
  dependencies, evidence summaries, discoveries, and handoffs in this copy.
- Follow Yegge's workflow: revise the execution plan outside Beads, translate
  the plan into detailed epics/issues, then iteratively review and refine
  those records before implementation. Keep all original task IDs and links.
- The coding agent performs the planning review, issue creation/refinement,
  implementation, verification, and tracker updates. Work on one issue at a time.
- Write tests before implementation and record the intended initial failure.
  A genuine disagreement after implementation must be reported for a developer
  ruling; do not silently change the governing artifacts or weaken tests.
- The developer authorizes implementing the specified T018–T024 behavior and
  the required T022 menu refactor. Use II(c) for the new specified realization;
  make the menu-caller refactor a separate II(b) commit stating that no
  specified behavior changed, with the full suite verified first.
- Do not accept `4;7` or move engine range checks into the parser. New behavior
  proposals can be recorded as future work, never silently implemented here.
- Record actual commands, outcomes, remaining criteria, next action, and
  commit/diff references in Beads. In-progress work must remain in progress.
- Local Git commits in this disposable working copy are authorized. Never
  push, publish, contact other people, read sibling transcript directories,
  launch subagents, or access files outside this project for the task.
- Use `bd prime` for Beads workflow guidance. Its generic ending/push guidance
  does not authorize remote operations: this disposable repository has no remote.
- Automatic Claude memory is disabled for the recovery demonstration. Save
  durable work context in the project and Beads; do not use conversation logs.
